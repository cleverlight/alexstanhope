<?php
 /**
  * This script will flag any .js files that fail our JSLint test
  * Based on http://www.amaxus.com/cms-blog/jslint-as-subversion-hook
  * (c) Alex Stanhope 2011
  * Licensed under the MIT/BSD licence
  */

 // variables
 $cwd = dirname(__FILE__);
 $lintCmd = 'java -jar '.$cwd.'/js.jar '.$cwd.'/jslint.js';

 // collect arguments passed in
 list( $ALL, $svnlook, $reposPath, $revId ) = $argv;
 $svnCommand = $svnlook.' changed '.$reposPath.' -r '.$revId.' ';
 exec( $svnCommand, $lines );
 // gecho( $svnCommand );

 // array collection used to determine pass/fail
 $jsLintErrors = array();

 foreach ( $lines as $line ) {

     // collection of relevant files
     $aMatches = array();
     // match A | U, then some spaces, then everything up to .js, then .js
     if (!preg_match('/^[AU]\s+(.+)(\.js)$/i',$line,$aMatches) ) {
         continue;
     }
     // gecho( $line );

     // extract the actual filename
     list( $ALL, $fileName, $extension ) = $aMatches;
     $filePath = $fileName . $extension;

     // see what has been committed
     $data = '';
     $cat =  'svnlook cat '.$reposPath.' '.$filePath.' 2>&1 ';
     exec( $cat, $data );

     // write javascript to temporary file for ease of linting
     $tmpFile = '/tmp/js' . time() . '.js';
     $fp = fopen( $tmpFile, 'w' );
     fwrite( $fp, join("\n",$data) );
     fclose( $fp );

     // jslint the file
     $returnValue = null;
     $errorCount = 0;
     $aErrors = array();
     exec( $lintCmd.' '.$tmpFile, $aErrors, $errorCount );

     // remove temporary file
     unlink( $tmpFile );

     // if there were any problems, then report them
     if($errorCount > 0) { // error count
         $jsLintErrors[] = array(
             'path' => $filePath,
             'errors' => $aErrors
         );
     }
 }

 function gecho($s) {
     static $cnt = 0;
     if (++$cnt < 50) {
         echo $s;
     } else if ($cnt === 50) {
         echo "\n ** Too many errors to display in SVN response! **";
     }
 }

 // If we have errors, then pass them back and throw a fail code 1
 if (count($jsLintErrors) > 0) {
     gecho ("** JAVASCRIPT JSLINT WARNINGS ** ");
     gecho ("\n   Your files are committed and your work is safe, but you should fix these problems and commit again.");
     foreach ($jsLintErrors as $err ) {
       gecho ("\n  WARNING: Bad JavaScript detected in {$err['path']}:\n");
       foreach($err['errors'] as $error) {
         gecho ("\n    $error");
       }
     }
     exit(42);
 }

