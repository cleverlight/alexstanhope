//
//  ContactApp01AppDelegate.m
//  ContactApp01
//
//  Created by Alex Stanhope on 22/12/2009.
//  Copyright Lightenna Limited 2009. All rights reserved.
//

#import "ContactApp01AppDelegate.h"
#import "ContactApp01ViewController.h"

@implementation ContactApp01AppDelegate

@synthesize window;
@synthesize viewController;


- (void)applicationDidFinishLaunching:(UIApplication *)application {    
    
    // Override point for customization after app launch    
    [window addSubview:viewController.view];
    [window makeKeyAndVisible];
}


- (void)dealloc {
    [viewController release];
    [window release];
    [super dealloc];
}


@end
