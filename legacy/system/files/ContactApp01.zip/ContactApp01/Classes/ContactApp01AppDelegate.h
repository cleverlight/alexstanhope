//
//  ContactApp01AppDelegate.h
//  ContactApp01
//
//  Created by Alex Stanhope on 22/12/2009.
//  Copyright Lightenna Limited 2009. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ContactApp01ViewController;

@interface ContactApp01AppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    ContactApp01ViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet ContactApp01ViewController *viewController;

@end

